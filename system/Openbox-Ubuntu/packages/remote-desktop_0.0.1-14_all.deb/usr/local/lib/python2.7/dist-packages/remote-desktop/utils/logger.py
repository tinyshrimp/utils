'''
Created on Jan 3, 2011

@author: xiwang
'''

class Logger(object):
    def __init__(self):
        pass
        